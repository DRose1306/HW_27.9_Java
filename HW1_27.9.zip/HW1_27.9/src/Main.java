import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите первое слово");
        String str1 = new Scanner(System.in).nextLine();

        System.out.println("Введите второе слово");
        String str2 = new Scanner(System.in).nextLine();

        int str1Lenght = str1.length();
        System.out.println("колличество букв в первом слове равна " + str1Lenght);

        int str2Lenght = str2.length();
        System.out.println("колличество букв во втором слове равна " + str2Lenght);

        StringBuilder sB = new StringBuilder();

        sB.append(str1, 0, str1.length() / 2).append(str2, str2Lenght / 2, str2Lenght);
        System.out.println(sB);


    }
}
//No1
//Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв
//(проверьте количество букв в слове).
//Нужно получить слово, состоящее из первой половины первого слова
// и второй половины второго слова. распечатать на консоль.
//Например:
//ввод - mama, papa
//вывод - mapa