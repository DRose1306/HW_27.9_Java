import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        String text = text(1000);
        System.out.println(text);
    }

    private static String word(int wordLeght) {
        String characters = "abcdefghijklmnopqrstyvwxyz";
        StringBuilder word = new StringBuilder();
        Random rnd = new Random();
        for (int i = 0; i < wordLeght; i++) {
            int index = rnd.nextInt(characters.length());
            word.append(characters.charAt(index));
        }
        return word.toString();
    }

    private static String sentence(int wordCount) {
        StringBuilder sentence = new StringBuilder();
        Random rnd = new Random();
        for (int i = 0; i < wordCount; i++) {
            sentence.append(word(rnd.nextInt(10)));
            if (i < wordCount - 1) {
                sentence.append(" ");
            }
        }
        char punctuation = ".!?".charAt(rnd.nextInt(3));
        sentence.append(punctuation).append(" ");
        return sentence.toString();
    }

    private static String text(int sentenceCount) {
        StringBuilder text = new StringBuilder();
        Random rnd = new Random();
        for (int i = 0; i < sentenceCount; i++) {
            text.append(sentence(rnd.nextInt(10)));
            if ((i + 1) % 5 == 0) {
                text.append("\n");
            }
        }
        return text.toString();
    }
}
//Напишите аналог Random для генерации строк.
// В реализуйте набор методов: первый метод генерирует слово заданной длины,
// состоящее из английских букв (любой набор букв).
// Второй метод генерирует предложение из заданного количества разных слов
// и ставит знак препинания (. или ! или ? или ...).
// Третий метод генерирует текст из заданного количества разных предложений.
// Сгенерируйте текст из 1000 предложений.