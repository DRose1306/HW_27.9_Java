public class Main {
    public static void main(String[] args) {
        String userStr = new String("I study Basic Java!");
        str(userStr);
    }

    private static void str(String str1) {
        //последний символ
        char lastCharOfString = str1.charAt(str1.length() - 1);
        System.out.println("Последний символ строки: " + lastCharOfString);
        //проверка на подстроку "Java"
        boolean check = str1.contains("Java");
        System.out.println(check);

        StringBuilder sB = new StringBuilder();
        //замена букв
        System.out.println(str1.replace("a", "o"));
        //верхний и нижний регистры
        System.out.println(str1.toUpperCase());
        System.out.println(str1.toLowerCase());
        //вырезание подстроки "Java"
        System.out.println(str1.substring(14, 18));
    }
}
//1. Создайте строку через new - I study Basic Java!
//2. Напишите метод, который принимает в качестве параметра строку, передайте в
//этот метод строку, которую создали в п.1
//3. Распечатать последний символ строки. Используем метод String.charAt().
//4. Проверить, содержит ли ваша строка подстроку “Java”. Используем метод
//String.contains().
//5. Заменить все символы “а” на “о”.
//6. Преобразуйте строку к верхнему регистру.
//7. Преобразуйте строку к нижнему регистру.
//8. Вырезать строку Java c помощью метода String.substring().