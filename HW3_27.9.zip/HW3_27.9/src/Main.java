public class Main {
    public static void main(String[] args) {
        String userStr = new String("AAAABBBCCCDDEG");
        System.out.println(convertString(userStr));
    }

    private static String convertString(String userStr) {
        StringBuilder sB = new StringBuilder();
        int count = 1;

        for (int i = 1; i < userStr.length(); i++) {
            if (userStr.charAt(i) == userStr.charAt(i - 1)) {
                count++;
            } else {
                if (count == 1) {
                    sB.append(userStr.charAt(i-1));
                } else {
                    sB.append(userStr.charAt(i-1)).append(count);
                }
                count = 1;
            }
        }
       if (count == 1) {
            sB.append(userStr.charAt(userStr.length() - 1));
        } else {
            sB.append(userStr.charAt(userStr.length() - 1)).append(count);
        }
        return sB.toString();
    }

}
//Задание из собеседования Яндекс:
//дана строка вида AAAABBBCCCDDEG...,
// состоящая только из заглавных символов латинского алфавита.
// Напишите метод, который «свернёт» строку к виду A4B3C3D2EG,
// т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.